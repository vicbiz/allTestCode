# Webpack Starter App

Webpack dev environment

### Version
1.0.0

## Install Dependencies
```bash
npm install 
```

## Run Dev Server
```bash
npm start
```

## Build To Dist Folder
```bash
npm run build
```