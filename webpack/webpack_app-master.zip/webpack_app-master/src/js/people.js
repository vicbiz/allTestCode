/*
function getHello(){
  return 'Hello There';
}
*/

let people = [
  {name: 'John Doe'},
  {name: 'Steve Smith'},
  {name: 'Carol Williams'}
];

module.exports = people;
