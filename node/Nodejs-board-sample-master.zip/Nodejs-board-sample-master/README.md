# Nodejs-board-sample
nodejs, express, mongodb(mongoose), ejs

cd project_name && npm start

before install project
1. install mongdb
2. create 'mydb' database
3. start mongod
