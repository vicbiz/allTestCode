module.exports = {
  entry: './app/scripts/index.js',
  output: {
    filename: './app/scripts/script.min.js'       
  }
};