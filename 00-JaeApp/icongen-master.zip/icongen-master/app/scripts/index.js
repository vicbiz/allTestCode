// webpack js list file

require("./tools.js");
require("./script.js");
