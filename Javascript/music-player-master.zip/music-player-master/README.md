# music-player
Simple music player using HTML, CSS &amp; JavaScript
